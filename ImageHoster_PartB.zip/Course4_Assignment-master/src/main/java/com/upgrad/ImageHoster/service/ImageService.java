package com.upgrad.ImageHoster.service;

import com.upgrad.ImageHoster.model.Image;

import java.util.List;

public interface ImageService{
    List<Image> getAll();
    List<Image> getByTag(String tagName);
    Image getByTitle(String title);
    Image getById(int id); // New method / service to get the image by it's id to fix the Part A issue 2
    Image getByTitleWithJoin(String title);
    void deleteByTitle(Image image);
    void deleteById(Image image); // Added this service to delete by id
    void save(Image image);
    void update(Image image);
}